/*
 * bullet.h
 *
 *  Created on: Dec 8, 2020
 *      Author: reidd
 */

#ifndef BULLET_H_
#define BULLET_H_

#include "main.h"

extern const uint8_t bulletBitmaps[];
extern const uint8_t bulletWidthPixels;
extern const uint8_t bulletHeightPixels;




#endif /* BULLET_H_ */
