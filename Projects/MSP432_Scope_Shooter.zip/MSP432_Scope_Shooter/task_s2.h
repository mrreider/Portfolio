/*
 * task_s2.h
 *
 *  Created on: Dec 7, 2020
 *      Author: Paul Bartlett
 */

#ifndef TASK_S2_H_
#define TASK_S2_H_

#include "main.h"
#include "ece353.h"

extern TaskHandle_t Task_s2_Handle;

void task_mkII_s2(void *pvParameters);

#endif /* TASK_S2_H_ */
