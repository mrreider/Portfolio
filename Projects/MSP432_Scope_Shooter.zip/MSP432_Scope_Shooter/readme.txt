Project written in C and freeRTOS to control the MSP432p401r Microcontroller along with the Education BoosterPack MKII. Creates and render a moving scope that can shoot animated projectiles when shaken. Will change to 'night mode' depending on the light level of the room.

Written in collaboration with Paul Bartlett.
